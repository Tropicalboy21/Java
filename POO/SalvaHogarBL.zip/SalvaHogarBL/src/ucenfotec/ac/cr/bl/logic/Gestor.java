package ucenfotec.ac.cr.bl.logic;

import ucenfotec.ac.cr.dl.Data;

public class Gestor {
    protected static Data datos = new Data();
}
